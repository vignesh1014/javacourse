package dayy18;
import java.util.*;

import dayy17.Employee;
public class HashsetEx {
	public static void main(String[] args) {
		HashSet<Employee> empList=new HashSet<>();
		Scanner sc=new Scanner(System.in);
		boolean isTrue=true;
		while(isTrue) {
			System.out.println("-----Menu-----");
			System.out.println("enter 1 for creating");
			System.out.println("enter 2 for view");
			System.out.println("enter 3 for modify");
			System.out.println("enter 4 for quit");
			int key=sc.nextInt();
			if(key==1) {
				System.out.println("enter the id");
				int id=sc.nextInt();
				boolean idExists = false;
                for (Employee e : empList) {
                    if (e.getId() == id) {
                        idExists = true;
                        break;
                    }
                }

                if (idExists) {
                    System.out.println("❌ Enter valid id. This ID already exists!");
                    continue; // skip adding
                }
                System.out.println("Enter the name: ");
                String name = sc.nextLine();

                System.out.println("Enter the phone no: ");
                long phno = sc.nextLong();

                System.out.println("Enter the salary: ");
                double salary = sc.nextDouble();

                
                Employee e = new Employee(id, name, phno, salary);
                empList.add(e);

                System.out.println("✅ Employee added successfully!");
                sc.nextLine();

			}
			else if(key==2) {
				if(empList.isEmpty()) {
					System.out.println("no details found");
				}
				else {
					for(Employee e:empList) {
						System.out.println(e);
					}
				}
			}
			else if(key==3) {
				System.out.println("Enter the id to modify");
				int sid=sc.nextInt();
				Employee found = null;

                for (Employee e : empList) {
                    if (e.getId() == sid) {
                        found = e;
                        break;
                    }
                }

                if (found != null) {
                    boolean modifyLoop = true;
                    while (modifyLoop) {
                        System.out.println("\n--- Modify Menu ---");
                        System.out.println("1. Modify ID");
                        System.out.println("2. Modify Name");
                        System.out.println("3. Modify Salary");
                        System.out.println("0. Exit Modify");
                        int choice = sc.nextInt();

                        switch (choice) {
                            case 1:
                                System.out.print("Enter new ID: ");
                                found.setId(sc.nextInt());
                                break;
                            case 2:
                                System.out.print("Enter new Name: ");
                                sc.nextLine(); 
                                found.setName(sc.nextLine());
                                break;
                            case 3:
                                System.out.print("Enter new Salary: ");
                                found.setSalary(sc.nextDouble());
                                break;
                            case 0:
                                modifyLoop = false;
                                break;
                            default:
                                System.out.println("Invalid choice.");
                        }
                    }
                } else {
                    System.out.println("Employee not found.");
                }

            } else if (key == 0) {
                System.out.println("Exiting...");
                isTrue = false;
            } else {
                System.out.println("Enter a valid option.");
            }
        }

        sc.close();
			}
		
	
}


