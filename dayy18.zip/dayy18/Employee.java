package dayy18;



public class Employee {
	private int id;
	private String name;
	private long ph;
	private double salary;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getPh() {
		return ph;
	}
	public void setPh(long ph) {
		this.ph = ph;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public Employee() {
	}
	public Employee(int id, String name, long ph, double salary) {
		super();
		this.id = id;
		this.name = name;
		this.ph = ph;
		this.salary = salary;
	}
	
	

}
