package day9;

public class ParagraphLetter {
	public static void main(String[] args) {
		String a="A paragraph is a self-contained unit of discourse in writing that deals with a particular point or idea. It typically consists of several sentences that are unified and coherent, meaning they work together to express a single thought clearly. The length of a paragraph can vary, but it is generally defined by its content rather than a specific number of sentences. The purpose of a paragraph is to organize ideas and provide clarity in writing, ensuring that each paragraph focuses on a distinct topic or argument.";
        int count=0;
        char b[]=a.toCharArray();
        for(char c:b) {
        	if(c == 'i') {
        		count++;
        	}
        }
        System.out.println(count);	
		//		int count=0;
//		for(int i=0;i<a.length();i++) {
//			if(a.charAt(i)=='i') {
//				count++;
//			}
			
//		}System.out.println("counted word of i is :"+count);
	}

}
