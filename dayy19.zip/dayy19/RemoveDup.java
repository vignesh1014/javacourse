package dayy19;
import java.util.*;
public class RemoveDup {
	public static void main(String[] args) {
		ArrayList<Integer> a=new ArrayList<Integer>();
		a.add(1);
		a.add(2);
		a.add(1);
		a.add(2);
		a.add(3);
		a.add(4);
		a.add(3);
		System.out.println("with duplicates : "+a);
		ArrayList<Integer> b=new ArrayList<Integer>();
		for (int num:a) {
			if(!b.contains(num)) {
				b.add(num);
			}
		}
		System.out.println("without duplicates :"+b);
	}

}
