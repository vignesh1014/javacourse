package dayy19;
import java.util.*;
public class ArrayListEx {
	public static void main(String[] args) {
		ArrayList<Integer> ar=new ArrayList<Integer>();
		ar.add(1);
		ar.add(2);
		ar.add(3);
		//using for loop
		for(int i=1;i<ar.size()-1;i++) {
			System.out.println("o/p using for loop "+ar);
		}
		//using for each
		for(int numbers :ar) {
			System.out.println("o/p using for each "+ar);
		}
		//using iterator
		Iterator <Integer> it=ar.iterator();
		while(it.hasNext()) {
			Integer are=it.next();
			System.out.println("o/p using iterator "+are);
		}
	}

}