package day15;

public class Book {
	public static void main(String[] args) {
		Library std1 = new Library(10,"Harry Potter","J.K.Rowling",40000);
		Library std2 = new Library(11,"Game Of Throns","Danerys Targeryan",100000);
		System.out.println(std1);
		System.out.println(std2);
		
		
	}

}
