package day15;

public class Library {
	private int id;
	private String bookname;
	private String authorName;
	private int price;
	
	public Library(){
		
	}
	
	public Library(int id,String bookname,String authorName,int price ){
		this.id=id;
		this.bookname=bookname;
		this.authorName=authorName;
		this.price=price;
	}
	
	public String toString() {
		return "ID :"+id+"\nBookName :"+bookname+"\nAurthorName :"+authorName+"\nPrice :"+price;
	}
}
