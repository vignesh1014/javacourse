package day4;

import java.util.Scanner;

public class Marks {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the mark you got: ");
		int mark = sc.nextInt();
		if(mark>35 && mark<100) {
			System.out.println("You got pass marks. ");
		}else if (mark<0 || mark>100) {
			System.out.println("Invalid Marks. ");
		}else {
			System.out.println("Yor got fail Marks. ");
		}
		
	}

}
