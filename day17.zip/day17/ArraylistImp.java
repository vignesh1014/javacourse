package day17;

import java.util.ArrayList;
import java.util.Scanner;

import day15.Student;

public class ArraylistImp {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Student std = new Student();
		ArrayList<Student> al = new ArrayList<Student>();
		//1 for create a New Student
		//2 for show Student
		//3 for modify a Student
		
		boolean isWork = true;
		
		while(isWork) {
			System.out.println("\nEnter any Choice : ");
			System.out.println("1 for create a New Student");
			System.out.println("2 for show Student");
			System.out.println("3 for modify a Student");
			System.out.println("0 for Exit");
			int key = sc.nextInt();
			
			
			if(key == 1) {
				System.out.println("Enter the Std id");
				int id = sc.nextInt();
				sc.nextLine();
				System.out.println("Enter the Student Name ");
				String name = sc.nextLine();
				System.out.println("Enter the Roll No ");
				int rollNo = sc.nextInt();
				System.out.println("Enter the Student Fees");
				double fees = sc.nextDouble();
				
				std = new Student(id,name,rollNo,fees);
				al.add(std);
				
					
			}else if(key ==2) {
				System.out.println(al);
				
			}else if(key == 3) {
				boolean istrue = true;
				while(istrue) {
					System.out.println("Enter any Choice : ");
					System.out.println("1 to modify id");
					System.out.println("2 to modify name");
					System.out.println("3 to modify fees");
					System.out.println("0 for Exit");
					int value = sc.nextInt();
					switch(value) {
					case 1:{
						System.out.println("select the id :");
						int y = sc.nextInt();
						sc.nextLine();
						boolean found = false;
						for (Student c : al) {
							if(y == c.getId()) {
								System.out.println("Enter the modified id :");
								int a=sc.nextInt();
								sc.nextLine();
								c.setId(a);
								found = true;
								break;
							}
						}
						if(!found) {
							System.out.println("enter correct id!");
						}
						break;
					}
					case 2:{
						System.out.println("select the id :");
						int y =sc.nextInt();
						sc.nextLine();
						boolean found = false;
						for (Student c : al) {
							if(y == c.getId()) {
								System.out.println("Enter the modified Name :");
								String a=sc.nextLine();
								c.setName(a);
								found = true;
								break;
							}
						
						}
						if(!found) {
							System.out.println("enter correct id!");
						}
						
						break;
					}
					case 3:{
						System.out.println("select the id :");
						int y = sc.nextInt();
						sc.nextLine();
						boolean found = false;
							for (Student c : al) {
							
							if(y == c.getId()) {
								System.out.println("Enter the modified fees :");
								int a=sc.nextInt();
								sc.nextLine();
								c.setFees(a);;;
								found = true;
								break;
							}
						
						   }
							if(!found) {
								System.out.println("enter correct id!");
							}
							break;
					}case 0:{
						System.out.println("end");
						istrue= false;
						break;
					}
					default :{
						System.out.println("Enter the correct choice!");
					}
					}					
					
				}
				
			}else if(key == 0) {
				System.out.println("End of program Thank You!");
				isWork = false;
			}
			
			else {
				System.out.println("Enter Crt Option");
			}
			
		}	

	}

}
