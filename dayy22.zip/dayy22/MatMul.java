package dayy22;
import java.util.*;
public class MatMul {
	public static void main(String[] args) {
		int a[][]= {{1,2,3},{4,5,6},{7,8,9}};
		int b[][]={{1,2,3},{4,5,6},{7,8,9}};
		int result[][]=new int[a.length][b.length];
		System.out.println("MAtrix a ---");
		for(int i=0;i<a.length;i++) {
			for(int j=0;j<a.length;j++) {
				System.out.print(a[i][j]+" ");
			}System.out.println();
		}
		System.out.println("Matrix b---");
		for(int i=0;i<b.length;i++) {
			for(int j=0;j<b.length;j++) {
				System.out.print(b[i][j]+" ");
			}System.out.println();
		}
		System.out.println("multiplication");
		for(int i=0;i<a.length;i++) {
			for(int j=0;j<a.length;j++) {
				result[i][j]=0;
				for(int k=0;k<b.length;k++) {
					result[i][j] +=a[i][k]*b[k][j];
				}
			}
		}
		for(int i=0;i<result.length;i++) {
			for(int j=0;j<result.length;j++) {
				System.out.print(result[i][j]+" ");
				
			}System.out.println();
		}
	}

}
