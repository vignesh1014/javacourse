package dayy22;

import java.util.Arrays;

public class SortingEx {
	public static void main(String[] args) {
		int a[]= {4,3,2,1};
		Arrays.sort(a);
		for(int c:a) {
			System.out.println(c);
		}
	}

}
