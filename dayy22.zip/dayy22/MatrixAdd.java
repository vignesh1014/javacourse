package dayy22;
import java.util.*;
public class MatrixAdd {
	public static void main(String[] args) {
		int a[][]= {{1,2,3},{4,5,6},{7,8,9}};
		int b[][]={{1,2,3},{4,5,6},{7,8,9}};
		int result[][]=new int[a.length][b.length];
		System.out.println("MAtrix a ---");
		for(int i=0;i<a.length;i++) {
			for(int j=0;j<a.length;j++) {
				System.out.print(a[i][j]+" ");
			}System.out.println();
		}
		System.out.println("Matrix b---");
		for(int i=0;i<b.length;i++) {
			for(int j=0;j<b.length;j++) {
				System.out.print(b[i][j]+" ");
			}System.out.println();
		}
		System.out.println("Matrix add---");
		for(int i=0;i<a.length;i++) {
			for(int j=0;j<b.length;j++) {
				 result[i][j]=a[i][j]+b[i][j];
				System.out.print(result[i][j]+" ");
			}System.out.println();
		}
	}

}
