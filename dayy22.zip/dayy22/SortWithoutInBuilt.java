package dayy22;
import java.util.*;
public class SortWithoutInBuilt {
	public static void main(String[] args) {
		int a[]= {23,2,1,5};
		int temp;
		for(int i=0;i<a.length;i++) {
			for(int j=0;j<a.length;j++) {
				if(a[i]<a[j]) {
					temp=a[j];
					a[j]=a[i];
					a[i]=temp;
					
				}
				
			}
		}
		for(int c:a) {
			System.out.println(c);
		}
	}

}
