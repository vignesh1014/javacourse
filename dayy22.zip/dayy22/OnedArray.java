package dayy22;
import java.util.*;
public class OnedArray {
	public static void main(String[] args) {
		int a[]= {1,2,3,4};
		for(int b:a) {
			System.out.println(b);
		}
	}

}
