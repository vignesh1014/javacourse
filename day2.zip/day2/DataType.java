package day2;

public class DataType {
	public static void main(String args[]) {
		byte age = 18;
		System.out.print("Byte Type " +age);
		short b = 140;
		System.out.println("Short Type "+b );
		int c = 2500;
		System.out.println("Int Type "+ c);
		long d = 6381423698l;
		System.out.println("Long Type "+d);
		float e = 22.314f;
		System.out.println("Float Type "+e);
		double f= 22.345678;
		System.out.println("Double Type "+ f);
		boolean istrue = true;
		System.out.println("IStrue? : "+ istrue);
		char g = 'p';
		System.out.println("Char Type :"+ g);
	}
	
	

}
