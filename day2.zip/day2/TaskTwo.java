package day2;

public class TaskTwo {
	public static void main(String[] args) {
		String a="This morning ";
		String name1="Vignesh ";
		String b=" woke up feeling ";
		String adj1="Energised ";
		String c=". it is going to be a ";
		String adj2="happy ";
		String d="day ! outside,a bunch of ";
		String noun1="gogs ";
		String e="s were protesting to keep ";
		String noun2="biscuits ";
		String f="in stores. They began to ";
		String verb1="march ";
		String g="to the rythm of the ";
		String noun3="footsteps ";
		String h=", which made all the ";
		String noun4="humans ";
		String i="s very ";
		String adj3="amused . ";
		String j="Concerned, ";
		String k="texted ";
		String name2="dhansuh ";
		String l=", who flew ";
		String m="to ";
		String place1="the sun ";
		String n="and dropped ";
		String o="in a puddle of frozen ";
		String noun5="river ";
		String p="woke up in the year ";
		String number="2001 ";
		String q=",in a world where ";
		String noun6="monkey d luffy ";
		String r="s ruled the world .";
		System.out.println(a+name1+b+adj1+c+adj2+d+noun1+e+noun2);
		System.out.println(f+verb1+g+noun3+h+noun4+i+adj3);
		System.out.println(j+name1+k+name2+l+name1+m+place1+n+name1+o+noun5+name1+p+number+q+noun6+r);
		
	}

}
