package dayy21;
import java.util.*;
public class CursorsEx {
	public static void main(String[] args) {
		Stack<Integer> ar=new Stack<Integer>();
		ar.add(1);
		ar.add(2);
		ar.add(3);
		Enumeration e=ar.elements();
		while(e.hasMoreElements()) {
			System.out.println("This is Enmeration Ex"+e.nextElement());
		}
		System.out.println("---------------------");
		//Iterator
		Iterator it=ar.iterator();
		while(it.hasNext()) {
			System.out.println("This is Cursor Ex "+it.next());
		}
		System.out.println("---------------------");
		//ListIterator
		ArrayList li=new ArrayList();
		li.add(1);
		li.add(2);
		li.add(3);
		ListIterator lt=li.listIterator();
		while(lt.hasPrevious()) {
			System.out.println("This is listITerator ex "+lt.previous());
		}
	}

}
