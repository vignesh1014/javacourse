package day14;

public class vehicle {
	public void startEngine(){
		System.out.println("vehicle engine started...");
	}
}
	class car extends vehicle{
		public void drive() {
			System.out.println("car is driving...");
		}
	}
	class ElectricCar extends car{
		public void chargebattery() {
			System.out.println("Electric car is charging...");
		}
	}
	class bike extends vehicle{
		public void kickStart() {
			System.out.println("Bike is kick-started...");
		}
	}

