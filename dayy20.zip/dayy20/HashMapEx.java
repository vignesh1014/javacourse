package dayy20;
import java.util.*;
public class HashMapEx {
	public static void main(String[] args) {
		HashMap<Integer,String> a=new HashMap<Integer,String>();
		a.put(1, "GOkul");
		a.put(2, "Vicky");
		a.put(3, "Ashwin");
		a.put(4, "Riyaaz");
		for(Integer no:a.keySet()) {
			System.out.println(no);
		}
		for(String k:a.values()) {
			System.out.println(k);
		}
		for(Map.Entry<Integer, String> c:a.entrySet()) {
			System.out.println(c.getKey()+":"+c.getValue());
		}
	}

}
