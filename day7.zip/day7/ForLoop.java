package day7;

public class ForLoop {
	public static void main(String[] args) {
		for(int i=1000;i>=1;i--) {
			System.out.println("Iteration: "+i);
		}
		for(int j=1;j<=1000;j++) {
			System.out.println("Iteration: "+j);
		}
	}

}
