package day7;

public class SumOfOdd {
	public static void main(String[] args) {
		int sum=0;
		for(int i=1;i<=100;i+=2) {
			sum= sum+i;
			
		}
		System.out.println(sum);
	}

}
