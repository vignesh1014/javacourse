package day7;

public class TrafficFine {

}
