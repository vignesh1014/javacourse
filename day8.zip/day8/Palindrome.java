package day8;

import java.util.Scanner;

public class Palindrome {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string: ");
		String a=sc.next();
		String str = a.trim();
		String rev = "";
		for(int i = str.length()-1;i>=0;i--) {
			rev = rev+str.charAt(i);
			
		}
		System.out.println(rev);
		if(str.equals(rev)) {
			System.out.println("It's A Palindrome!");
		}else {}
		System.out.println("It's Not A Palindrome!");
	}

}
