package day3;

public class Operators {
	public static void main(String args[]) {
		int a= 12;
		int b = 25;
		int c=10;
		int d=50;
		int e= 5;
		int f= 100;
		System.out.print("Enter the first number: \n"+a);
		System.out.println("Enter the second number: "+b);
		System.out.println();
		System.out.println("Arithmaetic Operations: ");
		System.out.println("Addition: "+ (a+b));
		System.out.println("Subraction "+ (a-b));
		System.out.println("Multiplication: "+ (a*b));
		System.out.println("Division: "+ (a/b));
		System.out.println("Modulus: "+ (a%b));
		System.out.println();
		System.out.println(a+" > "+b+":"+(a>b));
		System.out.println(a+" < "+b+":"+(a<b));
		System.out.println(a+" >= "+b+":"+(a>=b));
		System.out.println(a+" >= "+b+":"+(a>=b));
		System.out.println(a+" == "+b+":"+(a==b));
		System.out.println(a+" != "+b+":"+(a!=b));
		System.out.println();
		System.out.println("Logical operations: ");
		System.out.println("("+a+">"+c+" AND "+b+"<"+d+")"+":" + ((a>c)&&(b<d)));
		System.out.println("("+a+">"+e+" OR "+b+"<"+f+")"+":" + ((a<e)||(b>f)));
		System.out.println();
		System.out.println("Assignment Operators: ");
		System.out.println("Initial value: "+c);
		System.out.println("After += : "+(c+=12));
		System.out.println("After -= : "+(c-=12));
		System.out.println("After *= : "+(c*=12));
		System.out.println("After /= : "+(c/=10));
		System.out.println("After %= : "+(c%=12));
		System.out.println();
		System.out.println("Unary Operations : ");
		System.out.println("Intial value: "+ a);
		System.out.println("After increment: "+ (++a));
		System.out.println("After decrement: "+(--a) );
		
		
	}

}
