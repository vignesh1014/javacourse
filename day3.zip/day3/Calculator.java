package day3;
import java.util.Scanner;


public class Calculator {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter first number: ");
		int a = sc.nextInt();
		System.out.println("Enter second number: ");
		int b = sc.nextInt();
		System.out.println("Addition : "+ (a+b));
		System.out.println("Subraction : "+ (a-b));
		System.out.println("Multiplication : "+ (a*b));
		System.out.println("Divison : "+ (a/b));
		System.out.println("Modulus : "+ (a%b));
		
	}

}
