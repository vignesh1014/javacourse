package dayy11;

import java.util.Scanner;

public class EmployeeOops {
	int id;
	String name;
	long number;
	float salary;
	
	void result() {
		System.out.println("id no is : "+id);
		System.out.println("name is : "+name);
		System.out.println("number is: "+number);
		System.out.println("salary is :"+salary);
	}
	

}
